import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { createClient } from '@supabase/supabase-js';
import { randomBytes, createHash, randomUUID } from 'node:crypto';
import { z } from 'zod';

const required = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_EMAIL', 'ADMIN_PASSWORD_HASH', 'JWT_SECRET'];
const missing = required.filter((k) => !process.env[k]);
if (missing.length) console.warn(`Missing required environment variables: ${missing.join(', ')}`);
const supabase = process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false, autoRefreshToken: false } }) : null;
const app = express();
app.set('trust proxy', 1);
app.use(helmet());
const allowedOrigins = (process.env.FRONTEND_URL || 'http://localhost:5173').split(',').map((s) => s.trim());
app.use(cors({ origin(origin, cb) { if (!origin || allowedOrigins.includes(origin)) return cb(null, true); return cb(new Error('Origin not allowed by CORS')); }, credentials: false }));
app.use(express.json({ limit: '32kb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false }));
app.use('/api/public', rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const USD_BUNDLES = [
  { id: '5gb-trial', name: '5GB Data', validity: '2-Day Trial', price: 0, currency: 'USD', description: 'A free 2-day trial' },
  { id: '15gb-7d', name: '15GB Data', validity: '7-Day Plan', price: 0.99, currency: 'USD', description: '15GB for 7 days' },
  { id: '35gb-14d', name: '35GB Data', validity: '14-Day Plan', price: 1.99, currency: 'USD', description: '35GB for 14 days' },
  { id: '50gb-21d', name: '50GB Data', validity: '21-Day Plan', price: 2.99, currency: 'USD', description: '50GB for 21 days' },
  { id: 'unlimited-30d', name: 'Unlimited', validity: '30-Day Plan', price: 3.99, currency: 'USD', description: 'Unlimited data for 30 days' }
];
const safeError = (err) => ({ error: err?.message || 'Unexpected error' });
const dbReady = (req, res, next) => { if (!supabase) return res.status(503).json({ error: 'Database is not configured. Set Supabase environment variables.' }); next(); };
const admin = (req, res, next) => {
  const token = req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : '';
  try { req.admin = jwt.verify(token, process.env.JWT_SECRET); if (req.admin.role !== 'admin') throw new Error('not admin'); next(); }
  catch { return res.status(401).json({ error: 'Authentication required' }); }
};
const adminRoute = [dbReady, admin];
const asyncRoute = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const sha256 = (s) => createHash('sha256').update(s).digest('hex');
const makeToken = () => randomBytes(24).toString('base64url');
const money = (n) => Math.round(Number(n) * 100) / 100;
const bundleSchema = z.object({ id: z.string().min(1), name: z.string().min(1).max(80), validity: z.string().min(1).max(80), price: z.number().finite().min(0).max(10000), currency: z.literal('USD'), description: z.string().max(300).optional().default(''), enabled: z.boolean().default(true), promotionalLabel: z.string().max(80).optional().default('') });
const customerSchema = z.object({ name: z.string().trim().min(1).max(120), notes: z.string().max(2000).optional().default(''), telegramChatId: z.string().trim().max(100).optional().default(''), notificationsEnabled: z.boolean().optional().default(false), notificationPreferences: z.record(z.string(), z.unknown()).optional().default({}) });
const linkSchema = z.object({ customerId: z.string().uuid(), name: z.string().trim().min(1).max(120), bundles: z.array(bundleSchema).min(1), formConfig: z.record(z.string(), z.unknown()).optional().default({ phoneRequired: true }), paymentInstructions: z.string().max(2000).optional().default('Payment is pending. Follow only verified EcoCash instructions provided by the administrator. This website does not collect EcoCash PINs or one-time codes.'), telegramChatId: z.string().trim().max(100).optional().default(''), notificationsEnabled: z.boolean().optional().default(false), notificationPreferences: z.record(z.string(), z.unknown()).optional().default({ newOrder: true }) });

app.get('/health', (_req, res) => res.json({ ok: true, databaseConfigured: Boolean(supabase) }));
app.post('/api/auth/login', dbReady, asyncRoute(async (req, res) => {
  const parsed = z.object({ email: z.string().email(), password: z.string().min(1).max(300) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Enter a valid email and password.' });
  const emailOk = parsed.data.email.toLowerCase() === process.env.ADMIN_EMAIL.toLowerCase();
  const passwordOk = await bcrypt.compare(parsed.data.password, process.env.ADMIN_PASSWORD_HASH).catch(() => false);
  if (!emailOk || !passwordOk) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ role: 'admin', email: process.env.ADMIN_EMAIL }, process.env.JWT_SECRET, { expiresIn: '8h', issuer: 'starlink-admin' });
  res.json({ token, email: process.env.ADMIN_EMAIL, expiresIn: 28800 });
}));
app.get('/api/admin/bundles', ...adminRoute, asyncRoute(async (_req, res) => {
  const { data, error } = await supabase.from('bundle_catalog').select('*').order('sort_order', { ascending: true });
  if (error) throw error; res.json({ bundles: (data || []).map((b) => ({ id: b.bundle_id, name: b.name, validity: b.validity, price: Number(b.price), currency: 'USD', description: b.description, enabled: b.enabled, promotionalLabel: b.promotional_label || '' })) });
}));
app.put('/api/admin/bundles/:id', ...adminRoute, asyncRoute(async (req, res) => {
  const p = bundleSchema.safeParse({ ...req.body, id: req.params.id }); if (!p.success) return res.status(400).json({ error: p.error.issues[0].message });
  const b = p.data; const { data, error } = await supabase.from('bundle_catalog').update({ name: b.name, validity: b.validity, price: money(b.price), description: b.description, enabled: b.enabled, promotional_label: b.promotionalLabel }).eq('bundle_id', b.id).select().single();
  if (error) throw error; res.json({ bundle: { id: data.bundle_id, name: data.name, validity: data.validity, price: Number(data.price), currency: 'USD', description: data.description, enabled: data.enabled, promotionalLabel: data.promotional_label || '' } });
}));
app.get('/api/admin/dashboard', ...adminRoute, asyncRoute(async (_req, res) => {
  const [customers, links, orders, notifications] = await Promise.all([
    supabase.from('customers').select('id', { count: 'exact', head: true }),
    supabase.from('visitor_links').select('status', { count: 'exact' }),
    supabase.from('orders').select('id', { count: 'exact', head: true }),
    supabase.from('notifications').select('id', { count: 'exact', head: true }).eq('status', 'failed')
  ]);
  for (const r of [customers, links, orders, notifications]) if (r.error) throw r.error;
  const statuses = { draft: 0, published: 0, disabled: 0, unpublished: 0 };
  for (const row of links.data || []) statuses[row.status] = (statuses[row.status] || 0) + 1;
  res.json({ customers: customers.count || 0, links: links.count || 0, linkStatuses: statuses, orders: orders.count || 0, failedNotifications: notifications.count || 0 });
}));
app.get('/api/admin/customers', ...adminRoute, asyncRoute(async (_req, res) => {
  const { data, error } = await supabase.from('customers').select('*').order('created_at', { ascending: false });
  if (error) throw error; res.json({ customers: data });
}));
app.post('/api/admin/customers', ...adminRoute, asyncRoute(async (req, res) => {
  const p = customerSchema.safeParse(req.body); if (!p.success) return res.status(400).json({ error: p.error.issues[0].message });
  const { data, error } = await supabase.from('customers').insert({ name: p.data.name, notes: p.data.notes, telegram_chat_id: p.data.telegramChatId || null, notifications_enabled: p.data.notificationsEnabled, notification_preferences: p.data.notificationPreferences }).select().single();
  if (error) throw error; res.status(201).json({ customer: data });
}));
app.put('/api/admin/customers/:id', ...adminRoute, asyncRoute(async (req, res) => {
  const p = customerSchema.partial().safeParse(req.body); if (!p.success) return res.status(400).json({ error: p.error.issues[0].message });
  const v = p.data; const row = {};
  if (v.name !== undefined) row.name = v.name; if (v.notes !== undefined) row.notes = v.notes; if (v.telegramChatId !== undefined) row.telegram_chat_id = v.telegramChatId || null;
  if (v.notificationsEnabled !== undefined) row.notifications_enabled = v.notificationsEnabled; if (v.notificationPreferences !== undefined) row.notification_preferences = v.notificationPreferences;
  const { data, error } = await supabase.from('customers').update(row).eq('id', req.params.id).select().single();
  if (error) throw error; res.json({ customer: data });
}));
app.get('/api/admin/links', ...adminRoute, asyncRoute(async (req, res) => {
  let q = supabase.from('visitor_links').select('id,customer_id,name,token,status,bundles,form_config,payment_instructions,telegram_chat_id,notifications_enabled,notification_preferences,created_at,updated_at,customers(name)').order('created_at', { ascending: false });
  if (req.query.customerId) q = q.eq('customer_id', req.query.customerId);
  const { data, error } = await q; if (error) throw error;
  const origin = (process.env.PUBLIC_APP_URL || '').replace(/\/$/, '');
  res.json({ links: (data || []).map((l) => ({ ...l, url: origin ? `${origin}/l/${l.token}` : null })) });
}));
app.post('/api/admin/links', ...adminRoute, asyncRoute(async (req, res) => {
  const p = linkSchema.safeParse(req.body); if (!p.success) return res.status(400).json({ error: p.error.issues[0].message });
  const v = p.data;
  const { data: customer, error: customerError } = await supabase.from('customers').select('id,telegram_chat_id,notifications_enabled').eq('id', v.customerId).single();
  if (customerError || !customer) return res.status(400).json({ error: 'Selected customer does not exist.' });
  const { data: catalogRows, error: catalogError } = await supabase.from('bundle_catalog').select('*').in('bundle_id', v.bundles.map((b) => b.id));
  if (catalogError) throw catalogError;
  const catalogById = new Map((catalogRows || []).map((b) => [b.bundle_id, b]));
  const savedBundles = [];
  for (const selected of v.bundles) {
    const catalog = catalogById.get(selected.id);
    if (!catalog) return res.status(400).json({ error: `Unknown bundle: ${selected.id}` });
    if (selected.enabled && !catalog.enabled) return res.status(400).json({ error: `${catalog.name} is disabled in the bundle catalog.` });
    savedBundles.push({ id: catalog.bundle_id, name: catalog.name, validity: catalog.validity, price: money(catalog.price), currency: 'USD', description: catalog.description, enabled: Boolean(selected.enabled), promotionalLabel: catalog.promotional_label || '' });
  }
  if (v.notificationsEnabled && !(v.telegramChatId || customer.telegram_chat_id)) return res.status(400).json({ error: 'A Telegram Chat ID is required when notifications are enabled.' });
  const token = makeToken();
  const { data, error } = await supabase.from('visitor_links').insert({ customer_id: v.customerId, name: v.name, token, token_hash: sha256(token), status: 'draft', bundles: savedBundles, form_config: v.formConfig, payment_instructions: v.paymentInstructions, telegram_chat_id: v.telegramChatId || customer.telegram_chat_id || null, notifications_enabled: v.notificationsEnabled, notification_preferences: v.notificationPreferences, config_version: 1 }).select('id,customer_id,name,token,status,bundles,created_at').single();
  if (error) throw error;
  const origin = (process.env.PUBLIC_APP_URL || '').replace(/\/$/, '');
  res.status(201).json({ link: { ...data, url: origin ? `${origin}/l/${token}` : null } });
}));
app.put('/api/admin/links/:id', ...adminRoute, asyncRoute(async (req, res) => {
  const p = linkSchema.partial().omit({ customerId: true }).safeParse(req.body); if (!p.success) return res.status(400).json({ error: p.error.issues[0].message });
  const v = p.data; const patch = { config_version: undefined };
  if (v.name !== undefined) patch.name = v.name; if (v.bundles !== undefined) patch.bundles = v.bundles.map((b) => ({ ...b, price: money(b.price) }));
  if (v.formConfig !== undefined) patch.form_config = v.formConfig; if (v.paymentInstructions !== undefined) patch.payment_instructions = v.paymentInstructions;
  if (v.telegramChatId !== undefined) patch.telegram_chat_id = v.telegramChatId || null; if (v.notificationsEnabled !== undefined) patch.notifications_enabled = v.notificationsEnabled;
  if (v.notificationPreferences !== undefined) patch.notification_preferences = v.notificationPreferences;
  delete patch.config_version;
  const { data: existing, error: e } = await supabase.from('visitor_links').select('id,config_version,status').eq('id', req.params.id).single(); if (e || !existing) return res.status(404).json({ error: 'Link not found' });
  patch.config_version = (existing.config_version || 1) + 1;
  const { data, error } = await supabase.from('visitor_links').update(patch).eq('id', req.params.id).select('id,customer_id,name,token,status,bundles,config_version').single();
  if (error) throw error; res.json({ link: { ...data, url: `${(process.env.PUBLIC_APP_URL || '').replace(/\/$/, '')}/l/${data.token}` } });
}));
app.post('/api/admin/links/:id/:action', ...adminRoute, asyncRoute(async (req, res) => {
  if (!['publish', 'unpublish', 'disable'].includes(req.params.action)) return res.status(404).json({ error: 'Unknown link action' });
  const { data: link, error: e } = await supabase.from('visitor_links').select('*').eq('id', req.params.id).single();
  if (e || !link) return res.status(404).json({ error: 'Link not found' });
  let status = req.params.action === 'publish' ? 'published' : req.params.action === 'disable' ? 'disabled' : 'unpublished';
  if (status === 'published') {
    if (link.notifications_enabled && !process.env.TELEGRAM_BOT_TOKEN) return res.status(400).json({ error: 'Configure TELEGRAM_BOT_TOKEN on the backend before publishing a link with Telegram notifications enabled.' });
    if (!Array.isArray(link.bundles) || !link.bundles.some((b) => b.enabled !== false)) return res.status(400).json({ error: 'Enable at least one bundle before publishing.' });
    if (link.notifications_enabled && !link.telegram_chat_id) return res.status(400).json({ error: 'Set a Telegram Chat ID or disable notifications before publishing.' });
    if (!process.env.PUBLIC_APP_URL) return res.status(400).json({ error: 'Set PUBLIC_APP_URL to the verified production domain before publishing.' });
  }
  const { data, error } = await supabase.from('visitor_links').update({ status, updated_at: new Date().toISOString() }).eq('id', link.id).select('id,status').single();
  if (error) throw error; res.json({ link: data });
}));
app.post('/api/admin/links/:id/telegram-test', ...adminRoute, asyncRoute(async (req, res) => {
  const { data: link, error } = await supabase.from('visitor_links').select('id,name,telegram_chat_id').eq('id', req.params.id).single();
  if (error || !link) return res.status(404).json({ error: 'Link not found.' });
  if (!link.telegram_chat_id) return res.status(400).json({ error: 'This link has no saved Telegram Chat ID.' });
  if (!process.env.TELEGRAM_BOT_TOKEN) return res.status(503).json({ error: 'Telegram bot token is not configured on the server.' });
  const response = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: link.telegram_chat_id, text: `Test notification for visitor link: ${link.name}. This exact link destination is reachable.` }), signal: AbortSignal.timeout(10000) });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok) return res.status(502).json({ connected: false, error: result.description || 'Telegram delivery failed.' });
  res.json({ connected: true, message: 'Test message sent to the link-specific destination.' });
}));

app.get('/api/public/links/:token', dbReady, asyncRoute(async (req, res) => {
  const { data: link, error } = await supabase.from('visitor_links').select('id,name,status,bundles,form_config,payment_instructions,customer_id').eq('token_hash', sha256(req.params.token)).single();
  if (error || !link || link.status !== 'published') return res.status(404).json({ error: 'This visitor link is unavailable.' });
  res.set('Cache-Control', 'no-store'); res.json({ link: { id: link.id, name: link.name, bundles: (link.bundles || []).filter((b) => b.enabled !== false), formConfig: link.form_config, paymentInstructions: link.payment_instructions } });
}));
const submitSchema = z.object({ bundleId: z.string().min(1).max(100), phone: z.string().trim().min(7).max(25).regex(/^[+0-9()\s-]+$/, 'Enter a valid phone number.'), idempotencyKey: z.string().uuid() });
app.post('/api/public/links/:token/submissions', dbReady, asyncRoute(async (req, res) => {
  const p = submitSchema.safeParse(req.body); if (!p.success) return res.status(400).json({ error: 'Provide a valid bundle, phone number and submission key.' });
  const { data: link, error: le } = await supabase.from('visitor_links').select('*').eq('token_hash', sha256(req.params.token)).single();
  if (le || !link || link.status !== 'published') return res.status(404).json({ error: 'This visitor link is unavailable.' });
  const bundle = (link.bundles || []).find((b) => b.id === p.data.bundleId && b.enabled !== false);
  if (!bundle) return res.status(400).json({ error: 'That bundle is not available for this link.' });
  const orderRef = `ORD-${randomBytes(4).toString('hex').toUpperCase()}`;
  const notificationEnabled = Boolean(link.notifications_enabled && link.telegram_chat_id && link.notification_preferences?.newOrder !== false);
  const { data, error } = await supabase.rpc('create_order_with_notification', {
    p_order_ref: orderRef, p_customer_id: link.customer_id, p_link_id: link.id, p_bundle_id: bundle.id, p_bundle_name: bundle.name,
    p_amount: money(bundle.price), p_currency: 'USD', p_phone: p.data.phone, p_idempotency_key: p.data.idempotencyKey,
    p_payment_status: 'pending', p_notification_enabled: notificationEnabled, p_chat_id: notificationEnabled ? link.telegram_chat_id : null,
    p_config_version: link.config_version || 1, p_notification_preferences: link.notification_preferences || {}
  });
  if (error) { if (error.code === '23505') { const { data: old } = await supabase.from('orders').select('order_ref,payment_status,amount,currency').eq('idempotency_key', p.data.idempotencyKey).single(); if (old) return res.status(200).json({ order: old, duplicate: true }); } throw error; }
  res.status(201).json({ order: data, paymentInstructions: link.payment_instructions, payment: { provider: 'ecocash', initiated: false, reason: 'provider_not_configured' }, message: 'Order received. No automated EcoCash payment request was initiated because an authorized provider integration is not configured. Payment remains pending until independently verified.' });
}));
app.get('/api/admin/orders', ...adminRoute, asyncRoute(async (req, res) => {
  let q = supabase.from('orders').select('*,customers(name),visitor_links(name)').order('created_at', { ascending: false }).limit(200);
  if (req.query.customerId) q = q.eq('customer_id', req.query.customerId); if (req.query.linkId) q = q.eq('link_id', req.query.linkId);
  if (req.query.paymentStatus) q = q.eq('payment_status', req.query.paymentStatus);
  const { data, error } = await q; if (error) throw error; res.json({ orders: data });
}));
app.get('/api/admin/notifications', ...adminRoute, asyncRoute(async (_req, res) => {
  const { data, error } = await supabase.from('notifications').select('*,orders(order_ref),customers(name),visitor_links(name)').order('created_at', { ascending: false }).limit(300);
  if (error) throw error; res.json({ notifications: data });
}));
app.post('/api/admin/notifications/:id/retry', ...adminRoute, asyncRoute(async (req, res) => {
  const { data: n, error: e } = await supabase.from('notifications').select('id,status,attempts').eq('id', req.params.id).single();
  if (e || !n) return res.status(404).json({ error: 'Notification not found' });
  if (n.status === 'sent') return res.status(409).json({ error: 'This notification was already delivered.' });
  const { data, error } = await supabase.from('notifications').update({ status: 'queued', attempts: 0, next_attempt_at: new Date().toISOString(), last_error: null }).eq('id', n.id).select().single();
  if (error) throw error; res.json({ notification: data, message: 'Retry queued.' });
}));
app.post('/api/admin/customers/:id/telegram-test', ...adminRoute, asyncRoute(async (req, res) => {
  const p = z.object({ chatId: z.string().trim().min(1).max(100).optional() }).safeParse(req.body || {}); if (!p.success) return res.status(400).json({ error: 'Invalid Chat ID.' });
  const { data: customer, error } = await supabase.from('customers').select('id,name,telegram_chat_id').eq('id', req.params.id).single();
  if (error || !customer) return res.status(404).json({ error: 'Customer not found.' });
  const chatId = p.data.chatId || customer.telegram_chat_id; if (!chatId) return res.status(400).json({ error: 'Save a Telegram Chat ID first.' });
  if (!process.env.TELEGRAM_BOT_TOKEN) return res.status(503).json({ error: 'Telegram bot token is not configured on the server.' });
  const response = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: chatId, text: `Test notification for ${customer.name}. Your Telegram destination is reachable.` }), signal: AbortSignal.timeout(10000) });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok) return res.status(502).json({ connected: false, error: result.description || 'Telegram delivery failed.' });
  res.json({ connected: true, message: 'Telegram test message sent successfully.' });
}));
app.use((err, _req, res, _next) => { console.error('API error:', err?.message || 'unknown error'); res.status(500).json({ error: 'The request could not be completed.' }); });

// DB-backed queue worker. Run one Render worker instance for simple deployments.
let workerBusy = false;
async function processNotifications() {
  if (!supabase || !process.env.TELEGRAM_BOT_TOKEN || workerBusy) return;
  workerBusy = true;
  try {
    const { data: jobs, error } = await supabase.rpc('claim_notifications', { p_limit: 10 });
    if (error) { console.error('Notification queue claim failed:', error.message); return; }
    for (const job of jobs || []) {
      let status = 'failed'; let errorText = null;
      try {
        const prefs = job.message_fields || {};
        const lines = ['NEW DATA BUNDLE ORDER', `Order Reference: ${job.order_ref}`, `Bundle: ${job.bundle_name}`, `Amount: USD ${Number(job.amount).toFixed(2)}`, `Payment Status: ${job.payment_status}`, `Phone: ${job.phone}`, `Submitted: ${new Date(job.order_created_at).toISOString()}`];
        const response = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: job.intended_chat_id, text: lines.filter((line) => { if (line.startsWith('Phone:')) return prefs.phone !== false; if (line.startsWith('Amount:')) return prefs.amount !== false; return true; }).join('\n') }), signal: AbortSignal.timeout(10000) });
        const result = await response.json().catch(() => ({})); if (!response.ok || !result.ok) throw new Error(result.description || `Telegram HTTP ${response.status}`); status = 'sent';
      } catch (err) { errorText = String(err?.message || 'Delivery failed').slice(0, 500); }
      const attempts = Number(job.attempts || 0); const terminal = status !== 'sent' && attempts >= 8;
      await supabase.from('notifications').update({ status: status === 'sent' ? 'sent' : terminal ? 'failed' : 'queued', attempts, last_error: errorText, sent_at: status === 'sent' ? new Date().toISOString() : null, next_attempt_at: status === 'sent' || terminal ? null : new Date(Date.now() + Math.min(60, 2 ** attempts) * 1000).toISOString() }).eq('id', job.id);
    }
  } catch (err) { console.error('Notification worker error:', err?.message || 'unknown error'); }
  finally { workerBusy = false; }
}
if (process.env.RUN_NOTIFICATION_WORKER !== 'false') setInterval(processNotifications, Math.max(3000, Number(process.env.NOTIFICATION_POLL_MS || 5000))).unref();
const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`Starlink admin API listening on ${port}`));
