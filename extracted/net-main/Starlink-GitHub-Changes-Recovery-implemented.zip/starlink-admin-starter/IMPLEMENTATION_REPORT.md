# Implementation report

## Changes made

- Checkout now says the phone number is for the order and that the form does not initiate an EcoCash payment request.
- The visitor submit button now says `Submit order & view payment instructions`, avoiding a false claim that payment authentication has started.
- After order creation, checkout clearly reports that automated EcoCash payment was not initiated, shows the order reference, and keeps payment pending.
- Checkout warns customers not to enter or share EcoCash PINs or one-time authentication codes on the website.
- The backend submission response explicitly reports `payment.initiated: false` and `provider_not_configured` so the frontend does not infer a payment request succeeded.
- Phone-number validation now restricts input to common phone-number characters and a reasonable length.
- Publishing a link with Telegram notifications enabled now requires the backend `TELEGRAM_BOT_TOKEN` to be configured, in addition to a destination Chat ID.
- Added `ECOCASH_AND_TELEGRAM_SETUP.md` with the safe payment integration boundary and Telegram setup requirements.

## Existing behaviour preserved

- The visitor chooses a bundle and submits a phone number.
- The server validates the selected bundle against the saved link bundle list and creates an order with pending payment status.
- The database RPC queues Telegram order notification details to the configured Chat ID when notifications are enabled.
- The notification worker and Admin retry/history routes remain in place.

## Not completed / blocked

- The archive contains no official EcoCash merchant API adapter, API documentation, merchant credentials, or verified webhook contract. A real phone-initiated EcoCash payment prompt cannot be safely implemented without these. No fake provider request was added.
- No PIN, OTP, or four-digit authentication-code field or Telegram forwarding was added. Those credentials must only be entered into the official EcoCash authentication channel and must never be sent to the Admin.
- Payment-confirmed events cannot be safely implemented until the authorized provider callback/verification contract is supplied.
- The uploaded archive is a starter snapshot, not the original production repository. The original visitor assets and payment integration are not present.

## Verification

- `node --check backend/src/index.js`: passed.
- `npm test` in `backend`: passed (3 tests).
- `tsc -b` in `frontend`: passed.
- Full Vite production build and live Telegram/EcoCash tests were not run because dependencies/credentials/provider configuration are not present in this workspace.
